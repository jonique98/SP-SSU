import java.util.ArrayList;
import java.util.Optional;

import org.w3c.dom.Text;

public class ObjectCode {
	public ObjectCode() {
		_sectionName = Optional.empty();
		_startAddress = Optional.empty();
		_programLength = Optional.empty();
		_initialPC = Optional.empty();

		_refers = new ArrayList<String>();
		_texts = new ArrayList<Text>();
		_mods = new ArrayList<Modification>();
		_defines = new ArrayList<Define>();
	}

	public void setSectionName(String sectionName) {
		_sectionName = Optional.of(sectionName);
	}

	public void setStartAddress(int address) {
		_startAddress = Optional.of(address);
	}

	public void setProgramLength(int length) {
		_programLength = Optional.of(length);
	}

	public void addDefineSymbol(String symbolName, int address) {
		_defines.add(new Define(symbolName, address));
	}

	public void addReferSymbol(String symbolName) {
		_refers.add(symbolName);
	}

	public void addText(int address, String value) {
		_texts.add(new Text(address, value));
	}

	public void addModification(String symbolNameWithSign, int address, int sizeHalfByte) {
		_mods.add(new Modification(address, sizeHalfByte, symbolNameWithSign));
	}

	public void setInitialPC(int address) {
		_initialPC = Optional.of(address);
	}

	/**
	 * ObjectCode 객체를 String으로 변환한다. Assembler.java에서 오브젝트 코드를 출력하는 데에 사용된다.
	 */
	@Override
	public String toString() {
		if (_sectionName.isEmpty() || _startAddress.isEmpty() || _programLength.isEmpty())
			throw new RuntimeException("illegal operation");
	
		String sectionName = _sectionName.get();
		int startAddress = _startAddress.get();
		int programLength = _programLength.get();
	
		String header = String.format("H%-6s%06X%06X\n", sectionName, startAddress, programLength);
	
		// Define Record
		StringBuilder define = new StringBuilder();
		if (!_defines.isEmpty()) {
			define.append("D");
			for (Define def : _defines) {
				define.append(String.format("%-6s%06X", def.symbolName, def.address));
			}
			define.append("\n");
		}
	
		// Reference Record
		StringBuilder refer = new StringBuilder();
		if (!_refers.isEmpty()) {
			refer.append("R");
			for (String ref : _refers) {
				refer.append(String.format("%-6s", ref));
			}
			refer.append("\n");
		}
	
		// Text Records
		StringBuilder text = new StringBuilder();
		int currentRecordLength = 0;
		int currentRecordStartAddress = 0;
		for (Text tx : _texts) {
			if (currentRecordLength == 0) {
				currentRecordStartAddress = tx.address;
				text.append(String.format("T%06X", currentRecordStartAddress));
			}
			if (currentRecordLength + (tx.value.length() / 2) > 0x1D) {
				text.append(String.format("%02X", currentRecordLength));
				text.append(tx.value.substring(0, 0x1D * 2 - currentRecordLength));
				text.append("\n");
				tx.value = tx.value.substring(0x1D * 2 - currentRecordLength);
				currentRecordLength = 0;
				text.append(String.format("T%06X", tx.address + (0x1D * 2 - currentRecordLength) / 2));
			}
			text.append(tx.value);
			currentRecordLength += tx.value.length() / 2;
			if (currentRecordLength >= 0x1D) {
				text.append("\n");
				currentRecordLength = 0;
			}
		}
		if (currentRecordLength > 0) {
			text.append(String.format("%02X", currentRecordLength)).append("\n");
		}
	
		// Modification Records
		StringBuilder modification = new StringBuilder();
		for (Modification mod : _mods) {
			modification.append(String.format("M%06X%02X+%s\n", mod.address, mod.sizeHalfByte, mod.symbolNameWithSign));
		}
	
		// End Record
		String end = "E" + _initialPC.map(x -> String.format("%06X", x)).orElse("") + "\n";
	
		return header + define.toString() + refer.toString() + text.toString() + modification.toString() + end;
	}
	

	class Define {
		Define(String symbolName, int address) {
			this.symbolName = symbolName;
			this.address = address;
		}

		String symbolName;
		int address;
	}

	class Text {
		Text(int address, String value) {
			this.address = address;
			this.value = value;
		}

		int address;
		String value;
	}

	class Modification {
		Modification(int address, int sizeHalfByte, String symbolNameWithSign) {
			this.address = address;
			this.sizeHalfByte = sizeHalfByte;
			this.symbolNameWithSign = symbolNameWithSign;
		}

		int address;
		int sizeHalfByte;
		String symbolNameWithSign;
	}

	// TODO: private field 선언.
	private Optional<String> _sectionName;
	private Optional<Integer> _startAddress;
	private Optional<Integer> _programLength;
	private Optional<Integer> _initialPC;
	private ArrayList<Define> _defines;

	private ArrayList<String> _refers;
	private ArrayList<Text> _texts;
	private ArrayList<Modification> _mods;
}
